<?php

namespace Gregorio\Exception;

class ValidateExecption extends \Exception
{

}
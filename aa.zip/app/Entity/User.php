<?php

namespace Gregorio\Entity;

class User
{
    public ?string $username = null;
    public ?string $password = null;


}
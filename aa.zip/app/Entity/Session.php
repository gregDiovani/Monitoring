<?php

namespace Gregorio\Entity;

class Session
{
    public ?string $id = null;
    public ?string $userId =null;


}
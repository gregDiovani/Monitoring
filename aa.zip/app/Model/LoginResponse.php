<?php

namespace Gregorio\Model;

use Gregorio\Entity\User;

class LoginResponse
{
    public User $user;

}
<?php

namespace Gregorio\Model;

class RegisterRequest
{
    public ?string $id = null;
    public ?string $username = null;
    public ?string $password = null;



}
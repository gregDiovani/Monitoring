<?php

namespace Gregorio\Model;

use Gregorio\Entity\Pulsa;

class PulsaResponse
{
    public Pulsa $pulsa;

}


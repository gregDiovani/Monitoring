<?php

namespace Gregorio\Entity;

class Pulsa
{
    public ?int $pulsa = null;
    public ?string $id_kamar = null;
    public ?string $receiptID = null;


}
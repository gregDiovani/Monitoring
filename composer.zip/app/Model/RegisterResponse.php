<?php

namespace Gregorio\Model;

use Gregorio\Entity\User;

class RegisterResponse
{
    public User $user;
}
<?php

namespace Gregorio\Model;

class LoginRequest
{
    public ?string $username = null;
    public ?string $password = null;

}